"""Notification system module for the flexible alert system.

Author: Shaun Clarke
Course: CSC6301

Copilot is in my VSCODE editor and i accept and reject it's suggestions as i see fit.
So yes copilot is helping me write this code, but i am the one who is ultimately responsible for the final product.

Provides a small notification framework built on composition rather than
inheritance. NotificationMedium is the interface (an abstract base class)
that every delivery channel implements. EmailService and SMSService are
concrete channels. AlertSystem holds a single NotificationMedium and
delegates delivery to it, so the active channel can be swapped at runtime
without touching AlertSystem itself.

The design choice was a calculated decision to keep things simple and easy to maintain. Adding a new channel, for example, a
WhatsApp service means writing one new class that implements the
interface. The AlertSystem does not change, and there is no class hierarchy to
rewrite.

Typical usage would be:
    from notification_system import AlertSystem, EmailService, SMSService

    system: AlertSystem = AlertSystem(EmailService())
    system.notify_user("Server back online")

    system.set_medium(SMSService())
    system.notify_user("Disk usage at 90 percent")

    log: list[str] = system.get_log()
"""

from abc import ABC, abstractmethod

__author__ = "Shaun Clarke"
__version__ = "1.0"


class NotificationMedium(ABC):
    """Interface for any channel that can deliver a notification.

    This class behaves like a contract every delivery channel must honor. The AlertSystem
    depends on this abstraction, not on any concrete channel, which is what
    lets the channels be swapped freely at runtime.
    """

    @abstractmethod
    def send(self, message: str) -> str:
        """Deliver a single message over this channel.

        Parameters:
            message (str): The notification text to deliver.

        Returns:
            str: A human readable confirmation describing what was sent.
        """
        raise NotImplementedError


class EmailService(NotificationMedium):
    """Concrete channel that delivers notifications by email.
    """

    def send(self, message: str) -> str:
        """Deliver a message as an email.

        Parameters:
            message (str): The notification text to deliver.

        Returns:
            str: Confirmation that the email was sent.
        """
        return f"[EMAIL] {message}"


class SMSService(NotificationMedium):
    """Concrete channel that delivers notifications by SMS.
    """

    def send(self, message: str) -> str:
        """Deliver a message as an SMS text.

        Parameters:
            message (str): The notification text to deliver.

        Returns:
            str: Confirmation that the SMS was sent.
        """
        return f"[SMS] {message}"


class AlertSystem:
    """Container that delegates notification delivery to a swappable medium.

    AlertSystem owns a NotificationMedium and a running log of every message
    sent during the session. It never knows or cares which concrete channel
    it holds, which is the point of buiding in the behavior rather than
    inheriting it.

    Attributes:
        medium (NotificationMedium): The channel currently used for delivery.
        log (list[str]): An ordered record of every message sent this session.
    """

    def __init__(self, medium: NotificationMedium) -> None:
        """Create an alert system with an initial delivery channel.

        Parameters:
            medium (NotificationMedium): The channel to start with.
        """
        self.medium: NotificationMedium = medium
        self.log: list[str] = []

    def set_medium(self, medium: NotificationMedium) -> None:
        """Swap the active delivery channel.

        Parameters:
            medium (NotificationMedium): The channel to switch to.
        """
        self.medium = medium

    def notify_user(self, message: str) -> str:
        """Send a message over the active channel and record it in the log.

        Parameters:
            message (str): The notification text to deliver.

        Returns:
            str: The confirmation returned by the active channel.
        """
        confirmation: str = self.medium.send(message)
        self.log.append(confirmation)
        return confirmation

    def get_log(self) -> list[str]:
        """Return the full session log of sent messages.

        Returns:
            list[str]: Every confirmation recorded, in the order it was sent.
        """
        return self.log


def main() -> None:
    """Run an interactive menu demonstrating the notification system.

    The menu lets the user switch the active channel, send messages, and
    print the session log, showing that delivery behavior changes at
    runtime without any change to AlertSystem.
    """
    # Building the channels once and reusing them as the active medium is swapped.
    channels: dict[str, NotificationMedium] = {
        "email": EmailService(),
        "sms": SMSService(),
    }
    system: AlertSystem = AlertSystem(channels["email"])
    active_name: str = "email"

    menu: str = (
        "\nFlexible Notification System\n"
        "1. Send a notification\n"
        "2. Switch channel (email / sms)\n"
        "3. Show session log\n"
        "4. Quit\n"
        "Choose an option: "
    )

    while True:
        choice: str = input(menu).strip()

        if choice == "1":
            message: str = input("Message: ").strip()
            if message:
                confirmation: str = system.notify_user(message)
                print(f"Sent -> {confirmation}")
            else:
                print("Nothing to send.")

        elif choice == "2":
            name: str = input("Channel (email / sms): ").strip().lower()
            if name in channels:
                system.set_medium(channels[name])
                active_name = name
                print(f"Active channel is now: {active_name}")
            else:
                print("Unknown channel. Use 'email' or 'sms'.")

        elif choice == "3":
            session_log: list[str] = system.get_log()
            if session_log:
                print(f"\nSession log ({len(session_log)} message(s)):")
                for index, entry in enumerate(session_log, start=1):
                    print(f"  {index}. {entry}")
            else:
                print("Log is empty.")

        elif choice == "4":
            print("Goodbye.")
            break

        else:
            print("Invalid option. Choose 1-4.")


if __name__ == "__main__":
    main()